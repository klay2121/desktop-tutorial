/**
 * 
 */
/**
 * 
 */
module P1TareaGrupo2 {
	requires json.simple;
}